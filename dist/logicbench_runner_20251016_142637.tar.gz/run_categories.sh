#!/usr/bin/env bash
set -euo pipefail

# ====== Config ======
MODEL="${LB_MODEL:-gpt-4o-mini}"
DATE="$(date +%Y%m%d)"
IN_DIR="data"
OUT_DIR="runs"
RPT_DIR="reports"
PROMPT_DIR="prompts"
SYSTEM_PROMPT="$PROMPT_DIR/system_en_strict.txt"

mkdir -p "$OUT_DIR" "$RPT_DIR"

declare -A ADDON=(
  [math]="$PROMPT_DIR/addon_math.txt"
  [logic]="$PROMPT_DIR/addon_logic.txt"
  [knowledge]="$PROMPT_DIR/addon_knowledge.txt"
  [devops]="$PROMPT_DIR/addon_devops.txt"
)
declare -A TEMP=([math]="0.0" [logic]="0.0" [knowledge]="0.1" [devops]="0.0")
declare -A MAXTOK=([math]="512" [logic]="768" [knowledge]="768" [devops]="512")

# ====== Helpers ======

# question→stem、choices正規化、(A)(B)(C)(D) 埋め込み抽出にも対応
convert_to_tmp() {
  local src_dev="$1" src_gold="$2" out_dev="$3" out_gold="$4"
  python3 - <<'PY' "$src_dev" "$src_gold" "$out_dev" "$out_gold"
import sys, json, re
src_dev, src_gold, out_dev, out_gold = sys.argv[1:5]
LETTERS="ABCDEFGHIJKLMNOPQRSTUVWXYZ"

def norm_choices(raw):
    L=[]; M={}
    if isinstance(raw,list) and raw:
        for i,ch in enumerate(raw):
            s="" if ch is None else str(ch)
            m=re.match(r'^\s*([A-Za-z])\s*[\)\.\:\-]\s*(.*)$', s)
            k=(LETTERS[i] if not m else m.group(1).upper())
            v=(s if not m else m.group(2)).strip()
            M[k]=v
        for k in sorted(M): L.append(M[k])
    elif isinstance(raw,dict) and raw:
        for k,v in sorted(raw.items()):
            if isinstance(k,str) and len(k)==1:
                M[k.upper()] = ("" if v is None else str(v)).strip()
        for k in sorted(M): L.append(M[k])
    return L,M

def extract_embed(q):
    pat=re.compile(
        r'^(?P<stem>.*?)(?:\(|\s)[Aa]\)\s*(?P<A>.+?)\s+(?:\(|\s)[Bb]\)\s*(?P<B>.+?)\s+(?:\(|\s)[Cc]\)\s*(?P<C>.+?)\s+(?:\(|\s)[Dd]\)\s*(?P<D>.+?)\s*$',
        re.S
    )
    m=pat.search(q.strip())
    if not m: return q, None
    stem=m.group("stem").strip()
    return (stem if stem else q), [m.group("A").strip(),m.group("B").strip(),m.group("C").strip(),m.group("D").strip()]

with open(src_dev,encoding="utf-8") as fi, open(out_dev,"w",encoding="utf-8") as fo:
    for line in fi:
        if not line.strip(): continue
        o=json.loads(line)
        stem=o.get("stem") or o.get("question") or o.get("prompt") or ""
        raw=o.get("choices") or o.get("options")
        L,M=([],{})
        if raw:
            L,M=norm_choices(raw)
        else:
            s2,c2=extract_embed(stem)
            if c2: stem, L, M = s2, c2, {k:v for k,v in zip(list("ABCD"), c2)}
        o["stem"]=stem; o["choices"]=L; o["options"]=M
        fo.write(json.dumps(o,ensure_ascii=False)+"\n")

with open(src_gold,encoding="utf-8") as fi, open(out_gold,"w",encoding="utf-8") as fo:
    for line in fi:
        if not line.strip(): continue
        o=json.loads(line)
        ans=str(o.get("answer","")).strip()
        m=re.match(r'^\s*([A-Za-z])', ans)
        o["answer"]= m.group(1).upper() if m else ans
        fo.write(json.dumps(o,ensure_ascii=False)+"\n")
PY
}

run_one () {
  local cat="$1"
  local DEV="$IN_DIR/dev_${cat}.jsonl"
  local GOLD="$IN_DIR/gold_${cat}.jsonl"
  local OUT="$OUT_DIR/pred_${DATE}_${cat}.jsonl"
  local RPT="$RPT_DIR/summary_${DATE}_${cat}.csv"
  local ADD="${ADDON[$cat]}"

  if [[ ! -s "$DEV" || ! -s "$GOLD" ]]; then
    echo "SKIP ${cat}: missing $DEV or $GOLD"; return
  fi
  if [[ ! -s "$SYSTEM_PROMPT" || ! -s "$ADD" ]]; then
    echo "SKIP ${cat}: missing prompts ($SYSTEM_PROMPT / $ADD)"; return
  fi

  echo "[start] ${cat}: $DEV -> $OUT (model=$MODEL)"

  # 変換結果（カテゴリ専用の一時ファイル）
  local DEV_TMP="$IN_DIR/dev_${cat}.tmp.jsonl"
  local GOLD_TMP="$IN_DIR/gold_${cat}.tmp.jsonl"
  convert_to_tmp "$DEV" "$GOLD" "$DEV_TMP" "$GOLD_TMP"

  # システムプロンプト連結
  local TMP_SYS
  TMP_SYS="$(mktemp)"
  cat "$SYSTEM_PROMPT" "$ADD" > "$TMP_SYS"

  # eval_runner に I/O を環境変数で指定（dev_20 差し替え不要）
  rm -f "$OUT_DIR/${cat}_raw.jsonl" "$OUT_DIR/${cat}_norm.jsonl"
  set +e
  LB_DEV_PATH="$DEV_TMP" \
  LB_OUT_RAW="$OUT_DIR/${cat}_raw.jsonl" \
  LB_OUT_NORM="$OUT_DIR/${cat}_norm.jsonl" \
  python3 scripts/eval_runner.py "$DEV" "$OUT" \
    --model "$MODEL" \
    --system_file "$TMP_SYS" \
    --temperature "${TEMP[$cat]}" \
    --max_tokens "${MAXTOK[$cat]}" \
    --dbg_id "cat:${cat},date:${DATE}"
  rc=$?
  set -e

  # 正規化があれば優先して OUT へ
  if [[ -s "$OUT_DIR/${cat}_norm.jsonl" ]]; then
    cp -f "$OUT_DIR/${cat}_norm.jsonl" "$OUT"
  elif [[ -s "$OUT_DIR/${cat}_raw.jsonl" ]]; then
    cp -f "$OUT_DIR/${cat}_raw.jsonl" "$OUT"
  fi
  rm -f "$TMP_SYS" "$DEV_TMP" "$GOLD_TMP"

  if [[ ! -s "$OUT" ]]; then
    echo "[error] ${cat}: prediction file not found (expected $OUT)"
    return
  fi

  # 採点（ローカルスコアラー。output/pred どちらでもOK）
  if [[ -n "$OUT" && -s "$OUT" && -n "$GOLD" && -s "$GOLD" ]]; then
    echo "[score] pred=$OUT  gold=$GOLD  -> $RPT"
    python3 scripts/score_simple_local.py "$OUT" "$GOLD" "$RPT" || true
  else
    echo "[score] skip: OUT or GOLD missing (OUT=\"$OUT\" GOLD=\"$GOLD\")"
  fi

  # （任意）レポ生成: そのままでも CSV は出来ているので省略可
  if [[ -s scripts/make_report_simple.py && -s "$RPT" ]]; then
    python3 scripts/make_report_simple.py \
      "$RPT" "$RPT_DIR/logicbench_${cat}_report_${DATE}.md" || true
  fi
}

main () {
  local cats=("$@")
  [[ ${#cats[@]} -eq 0 ]] && cats=(math logic knowledge devops)
  for c in "${cats[@]}"; do run_one "$c"; done
}
main "$@"
