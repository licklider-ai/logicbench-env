import sys, json, csv, pathlib
def load_pred(path):
    m={}
    with open(path, encoding="utf-8") as f:
        for line in f:
            if not line.strip(): continue
            o=json.loads(line)
            # output でも pred でもOK
            p = o.get("pred", o.get("output"))
            m[str(o.get("id"))] = (None if p is None else str(p).strip())
    return m
def load_gold(path):
    g={}
    with open(path, encoding="utf-8") as f:
        for line in f:
            if not line.strip(): continue
            o=json.loads(line)
            g[str(o.get("id"))] = str(o.get("answer")).strip()
    return g
def score(pred_path, gold_path, out_csv):
    pm, gm = load_pred(pred_path), load_gold(gold_path)
    ids = list(gm.keys()); ok = 0
    with open(out_csv, "w", newline="", encoding="utf-8") as fo:
        w=csv.writer(fo); w.writerow(["id","category","gold","pred","correct","cost_usd"])
        for i in ids:
            gold = gm.get(i,""); pred = pm.get(i,"")
            c = int(pred == gold); ok += c
            w.writerow([i,"unknown",gold,pred,c,"0.000000"])
    print(f"== Summary ==\nTotal: {len(ids)}  Correct: {ok}  Acc: {ok/len(ids) if ids else 0:.3f}")
if __name__=="__main__":
    if len(sys.argv)!=4:
        print("usage: python scripts/score_simple_local.py <pred.jsonl> <gold.jsonl> <out.csv>"); sys.exit(2)
    score(*sys.argv[1:4])
