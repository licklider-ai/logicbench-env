import os, json, re, sys, time, random
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional
from openai import OpenAI

MODEL   = os.getenv("LB_MODEL", "gpt-4o-mini")
IN_PATH = os.getenv("LB_DEV_PATH", "data/dev_20.jsonl")
RAW_OUT = os.getenv("LB_OUT_RAW", "runs/pred_raw.jsonl")
NORM_OUT= os.getenv("LB_OUT_NORM","runs/pred_normalized.jsonl")

LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY") or "")

def build_prompt(stem: str, choices: List[str]) -> Tuple[str, str, bool]:
    """returns (system, user, mode_letters)"""
    up = [c.strip().upper() for c in choices]
    is_yn = (len(up)==2 and set(up)<= {"YES","NO","TRUE","FALSE"}) or set(up)<= {"YES","NO"}
    if is_yn:
        system = "Answer with EXACTLY ONE token from this set: YES,NO. No words, no punctuation, no spaces, no quotes."
        user = f"{stem}\n\nReturn only one token: YES or NO."
        return system, user, False
    valid = LETTERS[:len(choices)]
    system = f"Answer with EXACTLY ONE uppercase letter from this set: {','.join(list(valid))}. No words, no punctuation, no spaces, no quotes."
    user = f"{stem}\n\nChoices:\n" + "\n".join([f"{LETTERS[i]}. {c}" for i,c in enumerate(choices)]) + f"\n\nReturn only one letter from [{valid}] and nothing else."
    return system, user, True

_ANS_RE = re.compile(r'\bANSWER:\s*([A-Z]|YES|NO|TRUE|FALSE|T|F|-?\d+)\b', re.I)
def _norm_tok(s:str)->str:
    s=s.strip().upper().replace("TRUE","YES").replace("FALSE","NO")
    return {"T":"YES","F":"NO"}.get(s,s)

def extract_one(raw:str,k:int,letters_mode:bool)->Optional[str]:
    if not raw: return None
    txt = raw.strip()
    m = _ANS_RE.search(txt)
    cand = _norm_tok(m.group(1)) if m else _norm_tok(txt)
    if letters_mode and not re.fullmatch(r'[A-Z]', cand):
        m2 = re.fullmatch(r'([A-Z])[\.\s]*', txt, re.I)
        if m2: cand = m2.group(1).upper()
    if letters_mode:
        return cand if re.fullmatch(r'[A-Z]', cand) and (ord(cand)-65)<k else None
    else:
        return cand if cand in {"YES","NO"} else None

def call_chat(system:str,user:str,budget:int)->str:
    r = client.chat.completions.create(
        model=MODEL,
        messages=[{"role":"system","content":system},{"role":"user","content":user}],
        max_completion_tokens=budget,
        temperature=0,
    )
    return (r.choices[0].message.content or "").strip()

def ask(stem:str, choices:List[str])->Tuple[Optional[str],str]:
    sysmsg,usermsg,letters_mode = build_prompt(stem, choices)
    k = len(choices) if letters_mode else 2
    raw_last = ""
    for b in (64,128,256):
        try:
            raw = call_chat(sysmsg,usermsg,b)
            tok = extract_one(raw,k,letters_mode)
            raw_last = raw
            if tok is not None: return tok, raw
        except Exception as e:
            raw_last = f"[chat.error {e}]"; time.sleep(0.8+random.random())
    return None, raw_last

def main():
    IN=Path(IN_PATH); RAW=Path(RAW_OUT); NORM=Path(NORM_OUT)
    items=[json.loads(l) for l in open(IN,encoding="utf-8") if l.strip()]
    RAW.parent.mkdir(parents=True, exist_ok=True)
    NORM.parent.mkdir(parents=True, exist_ok=True)

    ok=0; total=len(items)
    print(f"[start] {IN} -> {RAW} (total={total}, model={MODEL})")
    with open(RAW,"w",encoding="utf-8") as gra, open(NORM,"w",encoding="utf-8") as gno:
        for i,s in enumerate(items,1):
            sid=s.get("id")
            stem=s.get("stem"); choices=s.get("choices") or []
            if not stem or not choices:
                print(f"[warn] empty choices → skip id={sid}")
                continue
            tok, raw = ask(stem, choices)
            gra.write(json.dumps({"id":sid,"raw":raw},ensure_ascii=False)+"\n")
            if tok is None:
                print(f"[warn] format error → skip id={sid}")
                continue
            out=_norm_tok(tok)
            gno.write(json.dumps({"id":sid,"output":out},ensure_ascii=False)+"\n")
            ok+=1
            print(f"[{i}/{total}] {sid} ✓ {out}")
    print(f"[done] raw -> {RAW}")
    print(f"[done] normalized -> {NORM} ({ok} rows)")

if __name__=="__main__":
    if not os.getenv("OPENAI_API_KEY"):
        print("ERROR: OPENAI_API_KEY not set", file=sys.stderr); sys.exit(2)
    main()
